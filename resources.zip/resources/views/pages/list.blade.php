@extends('layouts.app')

@section('title', 'HomeEase | Browse Local Experts')

@section('content')
<style>
  /* =========================
   TABLET
========================= */
@media (max-width: 1200px) {
  .container {
    grid-template-columns: 240px 1fr;
    gap: 24px;
    padding: 0 20px;
  }

  .sidebar {
    padding: 22px;
    border-radius: 20px;
  }

  .results-header {
    padding: 0;
    gap: 12px;
  }

  .results-header h2 {
    font-size: 1.35rem;
  }

  .sort-dropdown {
    min-width: 170px;
  }

  .expert-card {
    gap: 18px;
    padding: 18px;
    border-radius: 24px;
  }

  .expert-img-wrapper {
    width: 180px;
    height: 165px;
  }

  .expert-name {
    font-size: 1.25rem;
  }

  .expert-price-section {
    min-width: 145px;
    padding-left: 18px;
  }

  .price-val {
    font-size: 1.45rem;
  }
}

/* =========================
   MOBILE / TABLET STACK
========================= */
@media (max-width: 992px) {
  .container {
    grid-template-columns: 1fr;
    gap: 20px;
    margin: 24px auto;
    padding: 0 16px;
  }

  .sidebar {
    display: none;
  }

  .mobile-filter-bar {
    display: flex;
    margin-bottom: 16px;
  }

  .results-header {
    flex-direction: column;
    align-items: stretch;
    padding: 0;
    margin-bottom: 18px;
  }

  .results-header h2 {
    font-size: 1.22rem;
    line-height: 1.35;
  }

  .sort-dropdown {
    width: 100%;
    min-width: 0;
  }

  .expert-list {
    gap: 16px;
  }

  .expert-card {
    flex-direction: column;
    gap: 14px;
    padding: 16px;
    border-radius: 22px;
  }

  .expert-card:hover {
    transform: none;
  }

  .expert-img-wrapper {
    width: 100%;
    height: 220px;
  }

  .expert-img {
    border-radius: 18px;
  }

  .badge-status {
    bottom: 12px;
    left: 12px;
    font-size: 0.68rem;
    padding: 5px 10px;
  }

  .expert-info {
    width: 100%;
  }

  .expert-name {
    font-size: 1.15rem;
    margin: 6px 0;
  }

  .expert-meta {
    gap: 8px;
    margin-bottom: 10px;
    font-size: 0.8rem;
  }

  .expert-price-section {
    border-left: none;
    border-top: 1px solid #F1F5F9;
    padding-left: 0;
    padding-top: 14px;
    min-width: 0;
    width: 100%;
    align-items: stretch;
  }

  .price-val {
    text-align: left;
    font-size: 1.35rem;
  }

  .book-now-btn {
    width: 100%;
    margin-top: 12px;
    padding: 13px 18px;
    border-radius: 12px;
  }

  .mobile-filter-scroll {
    padding-bottom: 3px;
  }

  .mobile-pill {
    padding: 9px 14px;
    font-size: 0.82rem;
  }

  .mobile-filter-open {
    padding: 10px 14px;
    font-size: 0.85rem;
  }
}

/* =========================
   SMALL MOBILE
========================= */
@media (max-width: 640px) {
  .container {
    margin: 18px auto;
    padding: 0 12px;
  }

  .results-header h2 {
    font-size: 1.08rem;
  }

  .expert-card {
    padding: 14px;
    border-radius: 20px;
  }

  .expert-img-wrapper {
    height: 190px;
  }

  .category-tag {
    font-size: 0.66rem;
  }

  .expert-name {
    font-size: 1.05rem;
  }

  .expert-meta {
    font-size: 0.76rem;
  }

  .price-val {
    font-size: 1.2rem;
  }

  .price-val span {
    font-size: 0.8rem;
  }

  .book-now-btn {
    font-size: 0.92rem;
    padding: 12px 16px;
  }

  .mobile-pill {
    padding: 8px 12px;
    font-size: 0.78rem;
  }

  .mobile-filter-open {
    padding: 9px 12px;
    font-size: 0.8rem;
  }

  .mobile-filter-drawer {
    padding: 18px 14px 24px;
    border-radius: 22px 22px 0 0;
  }

  .drawer-head h3 {
    font-size: 1rem;
  }

  .drawer-actions {
    flex-direction: column;
  }

  .drawer-btn {
    width: 100%;
  }
}

/* =========================
   VERY SMALL MOBILE
========================= */
@media (max-width: 420px) {
  .container {
    padding: 0 10px;
  }

  .expert-card {
    padding: 12px;
  }

  .expert-img-wrapper {
    height: 170px;
  }

  .expert-name {
    font-size: 1rem;
  }

  .expert-meta {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }

  .price-val {
    font-size: 1.1rem;
  }

  .book-now-btn {
    padding: 11px 14px;
    font-size: 0.88rem;
  }
}
:root {
  --primary: #7C3AED;
  --primary-light: #F5F3FF;
  --dark: #0F172A;
  --gray: #64748B;
  --white: #FFFFFF;
  --border: #E2E8F0;
  --bg: #FDFCFE;
  --success: #10B981;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background: var(--bg);
}

.container {
  max-width: 1300px;
  margin: 40px auto;
  padding: 0 5%;
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 40px;
}

/* Sidebar Filters */
.sidebar {
  position: sticky;
  top: 80px;
  height: fit-content;
  background: var(--white);
  padding: 30px;
  border-radius: 24px;
  border: 1px solid var(--border);
}

.filter-section {
  margin-bottom: 30px;
}

.filter-section h4 {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 1.2px;
  color: var(--gray);
  margin-bottom: 15px;
  font-weight: 800;
}

.filter-item {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 0.95rem;
  font-weight: 500;
}

.filter-item input {
  accent-color: var(--primary);
  width: 18px;
  height: 18px;
  cursor: pointer;
}

/* Mobile Filter Top Bar */
.mobile-filter-bar {
  display: none;
  margin-bottom: 18px;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
}

.mobile-filter-scroll {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  scrollbar-width: none;
  flex: 1;
  padding-bottom: 4px;
}

.mobile-filter-scroll::-webkit-scrollbar {
  display: none;
}

.mobile-pill {
  flex: 0 0 auto;
  padding: 10px 16px;
  border-radius: 999px;
  border: 1px solid var(--border);
  background: var(--white);
  color: var(--dark);
  font-size: 0.88rem;
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
  transition: 0.25s ease;
}

.mobile-pill.active {
  background: var(--primary);
  color: var(--white);
  border-color: var(--primary);
}

.mobile-filter-open {
  flex: 0 0 auto;
  padding: 11px 16px;
  border: none;
  border-radius: 14px;
  background: var(--primary);
  color: var(--white);
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
}

/* Mobile Filter Drawer */
.mobile-filter-overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.35);
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: 0.25s ease;
  z-index: 9998;
}

.mobile-filter-overlay.show {
  opacity: 1;
  visibility: visible;
  pointer-events: auto;
}

.mobile-filter-drawer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: -100%;
  background: var(--white);
  border-radius: 26px 26px 0 0;
  padding: 20px 18px 28px;
  z-index: 9999;
  box-shadow: 0 -20px 60px rgba(15, 23, 42, 0.16);
  transition: bottom 0.3s ease;
  max-height: 85vh;
  overflow-y: auto;
}

.mobile-filter-drawer.show {
  bottom: 0;
}

.drawer-handle {
  width: 54px;
  height: 5px;
  border-radius: 999px;
  background: #CBD5E1;
  margin: 0 auto 16px;
}

.drawer-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
  gap: 12px;
}

.drawer-head h3 {
  font-size: 1.1rem;
  font-weight: 800;
}

.drawer-close {
  background: #F8FAFC;
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 8px 12px;
  cursor: pointer;
  font-weight: 700;
}

.drawer-actions {
  display: flex;
  gap: 12px;
  margin-top: 22px;
}

.drawer-btn {
  flex: 1;
  padding: 14px 16px;
  border-radius: 14px;
  font-weight: 700;
  cursor: pointer;
  border: 1px solid var(--border);
}

.drawer-btn.primary {
  background: var(--primary);
  color: white;
  border-color: var(--primary);
}

.drawer-btn.secondary {
  background: var(--white);
  color: var(--dark);
}

/* Content Area */
.results-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding: 0 10px;
  gap: 14px;
}

.results-header h2 {
  font-size: 1.5rem;
  font-weight: 800;
  line-height: 1.3;
}

.results-header span {
  color: var(--primary);
}

.sort-dropdown {
  padding: 10px 15px;
  border-radius: 12px;
  border: 1px solid var(--border);
  background: var(--white);
  font-weight: 600;
  outline: none;
  cursor: pointer;
  min-width: 190px;
}

/* Expert List */
.expert-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.expert-card {
  background: var(--white);
  border: 1px solid var(--border);
  border-radius: 28px;
  padding: 20px;
  display: flex;
  gap: 25px;
  transition: 0.3s ease;
}

.expert-card:hover {
  border-color: var(--primary);
  transform: translateX(8px);
  box-shadow: 0 20px 40px rgba(124, 58, 237, 0.06);
}

.expert-card.hidden {
  display: none;
}

.expert-img-wrapper {
  position: relative;
  width: 200px;
  height: 180px;
  flex-shrink: 0;
}

.expert-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 20px;
}

.badge-status {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background: rgba(255,255,255,0.95);
  padding: 4px 10px;
  border-radius: 50px;
  font-size: 0.65rem;
  font-weight: 800;
  display: flex;
  align-items: center;
  gap: 5px;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--success);
}

.expert-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-width: 0;
}

.category-tag {
  font-size: 0.7rem;
  font-weight: 800;
  color: var(--primary);
  text-transform: uppercase;
  letter-spacing: 1px;
}

.expert-name {
  font-size: 1.5rem;
  font-weight: 800;
  margin: 5px 0;
  line-height: 1.25;
}

.expert-meta {
  display: flex;
  gap: 15px;
  color: var(--gray);
  font-size: 0.85rem;
  font-weight: 600;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.rating {
  color: #F59E0B;
}

.expert-desc {
  color: var(--gray);
  font-size: 0.9rem;
  line-height: 1.6;
}

.expert-price-section {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
  min-width: 160px;
  padding-left: 25px;
  border-left: 1px solid #F1F5F9;
}

.price-val {
  font-size: 1.8rem;
  font-weight: 800;
  color: var(--dark);
  text-align: right;
}

.price-val span {
  font-size: 0.9rem;
  color: var(--gray);
  font-weight: 400;
}

.book-now-btn {
  background: var(--primary);
  color: white;
  border: none;
  padding: 14px 24px;
  border-radius: 14px;
  font-weight: 700;
  width: 100%;
  margin-top: 15px;
  cursor: pointer;
  transition: 0.3s;
}

.book-now-btn:hover {
  background: var(--dark);
  transform: translateY(-2px);
}

.empty-state {
  display: none;
  text-align: center;
  background: var(--white);
  border: 1px dashed var(--border);
  border-radius: 24px;
  padding: 40px 20px;
  color: var(--gray);
  font-weight: 600;
}

.empty-state.show {
  display: block;
}

/* Tablet */
@media (max-width: 1200px) {
  .container {
    grid-template-columns: 250px 1fr;
    gap: 24px;
  }

  .expert-card {
    gap: 18px;
  }

  .expert-img-wrapper {
    width: 180px;
    height: 165px;
  }

  .expert-name {
    font-size: 1.35rem;
  }

  .price-val {
    font-size: 1.55rem;
  }
}

/* Mobile */
@media (max-width: 992px) {
  .container {
    grid-template-columns: 1fr;
    gap: 22px;
    margin: 24px auto;
    padding: 0 16px;
  }

  .sidebar {
    display: none;
  }

  .mobile-filter-bar {
    display: flex;
  }

  .results-header {
    flex-direction: column;
    align-items: stretch;
    padding: 0;
    margin-bottom: 18px;
  }

  .results-header h2 {
    font-size: 1.3rem;
  }

  .sort-dropdown {
    width: 100%;
    min-width: 0;
  }

  .expert-card {
    flex-direction: column;
    gap: 15px;
    padding: 16px;
    border-radius: 22px;
  }

  .expert-card:hover {
    transform: none;
  }

  .expert-img-wrapper {
    width: 100%;
    height: 220px;
  }

  .expert-price-section {
    border-left: none;
    padding-left: 0;
    align-items: stretch;
    border-top: 1px solid #F1F5F9;
    padding-top: 16px;
    min-width: 0;
  }

  .price-val {
    text-align: left;
    font-size: 1.5rem;
  }

  .book-now-btn {
    width: 100%;
  }
}

@media (max-width: 640px) {
  .container {
    margin: 18px auto;
    padding: 0 12px;
  }

  .mobile-filter-bar {
    gap: 8px;
    margin-bottom: 14px;
  }

  .mobile-pill {
    padding: 9px 14px;
    font-size: 0.82rem;
  }

  .mobile-filter-open {
    padding: 10px 14px;
    font-size: 0.85rem;
  }

  .results-header h2 {
    font-size: 1.18rem;
  }

  .expert-card {
    padding: 14px;
    border-radius: 20px;
  }

  .expert-img-wrapper {
    height: 190px;
  }

  .expert-name {
    font-size: 1.18rem;
  }

  .expert-meta {
    gap: 8px;
    font-size: 0.8rem;
  }

  .expert-desc {
    font-size: 0.86rem;
  }

  .price-val {
    font-size: 1.3rem;
  }

  .book-now-btn {
    padding: 13px 18px;
    border-radius: 12px;
  }

  .drawer-actions {
    flex-direction: column;
  }
}

.directory-main {
  min-width: 0;
}

.results-overview {
  background:
    radial-gradient(circle at top right, rgba(124, 58, 237, 0.18), transparent 32%),
    linear-gradient(135deg, #ffffff 0%, #f7f8ff 52%, #fdf2f8 100%);
  border: 1px solid rgba(124, 58, 237, 0.12);
  border-radius: 30px;
  padding: 28px;
  margin-bottom: 22px;
  box-shadow: 0 24px 50px rgba(15, 23, 42, 0.06);
}

.results-kicker {
  display: inline-flex;
  align-items: center;
  padding: 8px 12px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.82);
  border: 1px solid rgba(124, 58, 237, 0.14);
  color: var(--primary);
  font-size: 0.78rem;
  font-weight: 800;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin-bottom: 14px;
}

.results-overview h2 {
  font-size: 2rem;
  line-height: 1.12;
  color: var(--dark);
  margin-bottom: 10px;
}

.results-overview h2 span {
  color: var(--primary);
}

.results-subtitle {
  max-width: 760px;
  color: var(--gray);
  font-size: 0.98rem;
  line-height: 1.7;
}

.results-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-top: 20px;
}

.summary-chip {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 44px;
  padding: 10px 14px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.88);
  border: 1px solid rgba(148, 163, 184, 0.18);
  color: var(--dark);
  font-size: 0.9rem;
  font-weight: 700;
}

.summary-chip strong {
  font-size: 1rem;
}

.results-header-meta {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.results-count {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  padding: 8px 12px;
  border-radius: 999px;
  background: var(--primary-light);
  color: var(--primary);
  font-size: 0.82rem;
  font-weight: 800;
}

@media (max-width: 992px) {
  .container {
    padding: 0 14px 18px;
  }

  .mobile-filter-bar {
    position: sticky;
    top: 0;
    z-index: 30;
    padding: 12px;
    border-radius: 24px;
    background: rgba(253, 252, 254, 0.92);
    backdrop-filter: blur(14px);
    border: 1px solid rgba(226, 232, 240, 0.88);
    box-shadow: 0 18px 35px rgba(15, 23, 42, 0.08);
  }

  .results-overview {
    border-radius: 28px;
    padding: 22px 18px;
    margin-bottom: 18px;
  }

  .results-kicker {
    font-size: 0.72rem;
    margin-bottom: 12px;
  }

  .results-overview h2 {
    font-size: 1.45rem;
    line-height: 1.22;
  }

  .results-subtitle {
    font-size: 0.9rem;
    line-height: 1.6;
  }

  .results-summary {
    gap: 10px;
    margin-top: 16px;
  }

  .summary-chip {
    font-size: 0.82rem;
    border-radius: 14px;
  }

  .results-header {
    align-items: flex-start;
    padding: 0 2px;
    gap: 12px;
  }

  .results-header h2 {
    font-size: 1.05rem;
  }

  .sort-dropdown {
    width: auto;
    min-width: 152px;
  }

  .expert-card {
    padding: 14px;
    border-radius: 24px;
    box-shadow: 0 14px 30px rgba(15, 23, 42, 0.06);
  }

  .expert-img-wrapper {
    height: 188px;
    border-radius: 22px;
    overflow: hidden;
  }

  .expert-name {
    font-size: 1.12rem;
    margin-top: 2px;
  }

  .expert-meta {
    gap: 6px 10px;
    margin-bottom: 10px;
    font-size: 0.76rem;
  }

  .expert-desc {
    font-size: 0.84rem;
    line-height: 1.55;
  }

  .expert-price-section {
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding-top: 14px;
  }

  .price-val {
    text-align: left;
    font-size: 1.2rem;
    line-height: 1.1;
  }

  .book-now-btn {
    width: auto;
    min-width: 122px;
    margin-top: 0;
    padding: 12px 18px;
    border-radius: 14px;
  }
}

@media (max-width: 640px) {
  .container {
    margin: 14px auto 0;
    padding: 0 10px 18px;
  }

  .expert-list {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
  }

  .mobile-filter-bar {
    top: 0;
    padding: 10px;
    border-radius: 20px;
  }

  .results-overview {
    padding: 18px 16px;
    border-radius: 24px;
  }

  .results-overview h2 {
    font-size: 1.28rem;
  }

  .results-subtitle {
    font-size: 0.84rem;
  }

  .summary-chip {
    width: calc(50% - 5px);
    padding: 10px 12px;
  }

  .results-header h2 {
    font-size: 1rem;
  }

  .results-count {
    font-size: 0.76rem;
  }

  .expert-card {
    padding: 12px;
    border-radius: 22px;
    gap: 12px;
    height: 100%;
  }

  .expert-img-wrapper {
    height: 128px;
  }

  .expert-name {
    font-size: 0.95rem;
    line-height: 1.3;
  }

  .expert-meta {
    gap: 5px 8px;
    font-size: 0.7rem;
    margin-bottom: 8px;
  }

  .expert-desc {
    font-size: 0.76rem;
    line-height: 1.45;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .price-val {
    font-size: 1rem;
  }

  .book-now-btn {
    min-width: 0;
    width: 100%;
    padding: 10px 14px;
    font-size: 0.82rem;
  }
}

@media (max-width: 420px) {
  .container {
    padding: 0 8px 16px;
  }

  .expert-list {
    grid-template-columns: 1fr;
  }

  .expert-img-wrapper {
    height: 156px;
  }

  .expert-actions,
  .expert-price-section {
    flex-direction: column;
    align-items: stretch;
  }

  .book-now-btn {
    width: 100%;
  }

  .summary-chip {
    width: 100%;
  }

  .results-overview h2 {
    font-size: 1.18rem;
  }
}
</style>

<div class="container">
  <aside class="sidebar">
    <div class="filter-section">
      <h4>Categories</h4>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="cook" checked onchange="updateList()"> Cooks</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="cleaner" checked onchange="updateList()"> Cleaners</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="electrician" checked onchange="updateList()"> Electricians</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="plumber" checked onchange="updateList()"> Plumbers</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="babysitter" checked onchange="updateList()"> Babysitters</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="tutor" checked onchange="updateList()"> Tutors</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="driver" checked onchange="updateList()"> Drivers</label>
      <label class="filter-item"><input type="checkbox" class="cat-filter" value="beautician" checked onchange="updateList()"> Beauticians</label>
    </div>

    <div class="filter-section">
      <h4>Budget</h4>
      <label class="filter-item"><input type="radio" name="budget" value="all" checked onchange="updateList()"> Show All</label>
      <label class="filter-item"><input type="radio" name="budget" value="low" onchange="updateList()"> Under Rs. 2,000</label>
      <label class="filter-item"><input type="radio" name="budget" value="high" onchange="updateList()"> Rs. 2,000 and above</label>
    </div>
  </aside>

  <main class="directory-main">
    <section class="results-overview">
      <div class="results-kicker">Mobile-first directory</div>
      <h2>Find trusted experts in <span>Sahibzada Ajit Singh Nagar</span></h2>
      <p class="results-subtitle">Browse nearby professionals, compare pricing quickly, and book help in a layout that feels closer to a local services app on mobile.</p>
      <div class="results-summary">
        <div class="summary-chip"><strong id="resultsCount">24</strong>&nbsp;experts available</div>
        <div class="summary-chip">Same-day support</div>
        <div class="summary-chip">Verified local profiles</div>
      </div>
    </section>

    <div class="mobile-filter-bar">
      <div class="mobile-filter-scroll">
        <button type="button" class="mobile-pill active" data-cat="all" onclick="selectMobileCategory('all', this)">All</button>
        <button type="button" class="mobile-pill" data-cat="cook" onclick="selectMobileCategory('cook', this)">Cooks</button>
        <button type="button" class="mobile-pill" data-cat="cleaner" onclick="selectMobileCategory('cleaner', this)">Cleaners</button>
        <button type="button" class="mobile-pill" data-cat="electrician" onclick="selectMobileCategory('electrician', this)">Electricians</button>
        <button type="button" class="mobile-pill" data-cat="plumber" onclick="selectMobileCategory('plumber', this)">Plumbers</button>
        <button type="button" class="mobile-pill" data-cat="babysitter" onclick="selectMobileCategory('babysitter', this)">Babysitters</button>
        <button type="button" class="mobile-pill" data-cat="tutor" onclick="selectMobileCategory('tutor', this)">Tutors</button>
        <button type="button" class="mobile-pill" data-cat="driver" onclick="selectMobileCategory('driver', this)">Drivers</button>
        <button type="button" class="mobile-pill" data-cat="beautician" onclick="selectMobileCategory('beautician', this)">Beauticians</button>
      </div>
      <button type="button" class="mobile-filter-open" onclick="openMobileFilters()">Filters</button>
    </div>

    <div class="results-header">
      <div class="results-header-meta">
        <h2>Experts near you</h2>
        <div class="results-count" id="resultsCountBadge">24 matches</div>
      </div>
      <select class="sort-dropdown" onchange="sortData(this.value)">
        <option value="default">Recommended</option>
        <option value="low">Price: Low to High</option>
        <option value="high">Price: High to Low</option>
      </select>
    </div>

    <div class="expert-list" id="expert-container">

      <!-- COOKS -->
      <div class="expert-card" data-cat="cook" data-price="1800">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=400" class="expert-img" alt="Cook">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Home Cook</span>
          <h3 class="expert-name">Riya Sharma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (124)</span>
            <span>• 0.8 km away</span>
          </div>
          <p class="expert-desc">Verified expert in home-style cooking and nutritional meal planning. Specialized in Punjabi cuisine.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,800<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="cook" data-price="1600">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=400" class="expert-img" alt="Cook">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Family Cook</span>
          <h3 class="expert-name">Sunita Verma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (91)</span>
            <span>• 1.1 km away</span>
          </div>
          <p class="expert-desc">Daily veg and non-veg meal preparation for small and medium households.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,600<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="cook" data-price="2500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400" class="expert-img" alt="Chef">
          <div class="badge-status"><div class="dot"></div> Busy soon</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Specialty Chef</span>
          <h3 class="expert-name">Arjun Mehta</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (53)</span>
            <span>• 2.6 km away</span>
          </div>
          <p class="expert-desc">Party meals, premium dinner prep, and customized event cooking support.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 2,500<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- CLEANERS -->
      <div class="expert-card" data-cat="cleaner" data-price="1200">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1581578731548-c64695cc6954?auto=format&fit=crop&w=400" class="expert-img" alt="Cleaner">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Deep Cleaning</span>
          <h3 class="expert-name">Amit Singh</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (240)</span>
            <span>• 1.5 km away</span>
          </div>
          <p class="expert-desc">Professional sanitation and deep cleaning for households with equipment included.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,200<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="cleaner" data-price="1000">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?auto=format&fit=crop&w=400" class="expert-img" alt="Cleaner">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Home Cleaning</span>
          <h3 class="expert-name">Pooja Sharma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (103)</span>
            <span>• 2.0 km away</span>
          </div>
          <p class="expert-desc">General home cleaning, kitchen support, and regular maintenance cleaning visits.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,000<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="cleaner" data-price="1500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=400" class="expert-img" alt="Cleaner">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Office Cleaning</span>
          <h3 class="expert-name">Rakesh Kumar</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (77)</span>
            <span>• 3.1 km away</span>
          </div>
          <p class="expert-desc">Commercial space cleaning with flexible scheduling for offices and clinics.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,500<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- ELECTRICIANS -->
      <div class="expert-card" data-cat="electrician" data-price="500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1581093458791-9d2f2c3f2c9c?auto=format&fit=crop&w=400" class="expert-img" alt="Electrician">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Electrician</span>
          <h3 class="expert-name">Rajesh Kumar</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (150)</span>
            <span>• 1.2 km away</span>
          </div>
          <p class="expert-desc">Quick repair expert for switchboards, fittings, sockets, and minor electrical issues.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 500<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="electrician" data-price="2000">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=400" class="expert-img" alt="Electrician">
          <div class="badge-status" style="color: var(--gray);"><div class="dot" style="background: #cbd5e1;"></div> Available Mon</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Electric Repair</span>
          <h3 class="expert-name">Vikram Jha</h3>
          <div class="expert-meta">
            <span class="rating">★ 5.0 (42)</span>
            <span>• 3.2 km away</span>
          </div>
          <p class="expert-desc">Emergency repair specialist. Smart home installation and heavy wiring expert.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 2,000<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="electrician" data-price="650">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1555963966-b7ae5404b6ed?auto=format&fit=crop&w=400" class="expert-img" alt="Electrician">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Installation Expert</span>
          <h3 class="expert-name">Deepak Yadav</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (89)</span>
            <span>• 2.4 km away</span>
          </div>
          <p class="expert-desc">Appliance fitting, fan setup, new switch panel work, and same-day installation help.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 650<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- PLUMBERS -->
      <div class="expert-card" data-cat="plumber" data-price="450">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=400" class="expert-img" alt="Plumber">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Plumber</span>
          <h3 class="expert-name">Sandeep Verma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (96)</span>
            <span>• 1.7 km away</span>
          </div>
          <p class="expert-desc">Leak repairs, pipeline fixes, and urgent bathroom plumbing support.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 450<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="plumber" data-price="550">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1628744448840-55bdb2497bd4?auto=format&fit=crop&w=400" class="expert-img" alt="Plumber">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Bathroom Fittings</span>
          <h3 class="expert-name">Mohit Sharma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (68)</span>
            <span>• 2.1 km away</span>
          </div>
          <p class="expert-desc">Tap fittings, washbasin support, jet spray replacement, and bathroom setup work.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 550<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="plumber" data-price="500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=400" class="expert-img" alt="Plumber">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Pipe Repair</span>
          <h3 class="expert-name">Ramesh Patel</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.6 (71)</span>
            <span>• 3.5 km away</span>
          </div>
          <p class="expert-desc">Fast support for pipe leaks, motor line issues, and water flow problems.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 500<span>/visit</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- BABYSITTERS -->
      <div class="expert-card" data-cat="babysitter" data-price="800">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=400" class="expert-img" alt="Babysitter">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Babysitter</span>
          <h3 class="expert-name">Neha Gupta</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (58)</span>
            <span>• 1.0 km away</span>
          </div>
          <p class="expert-desc">Reliable child care support for daytime supervision and activity help.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 800<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="babysitter" data-price="900">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=400" class="expert-img" alt="Babysitter">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Infant Care</span>
          <h3 class="expert-name">Kavita Sharma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (44)</span>
            <span>• 2.4 km away</span>
          </div>
          <p class="expert-desc">Gentle infant and toddler support with feeding and nap routine handling.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 900<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="babysitter" data-price="850">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=crop&w=400" class="expert-img" alt="Babysitter">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Nanny Service</span>
          <h3 class="expert-name">Meera Joshi</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (39)</span>
            <span>• 2.8 km away</span>
          </div>
          <p class="expert-desc">Evening nanny support, homework time monitoring, and supervised play sessions.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 850<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- TUTORS -->
      <div class="expert-card" data-cat="tutor" data-price="600">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=400" class="expert-img" alt="Tutor">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Home Tutor</span>
          <h3 class="expert-name">Ankit Sharma</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (84)</span>
            <span>• 1.3 km away</span>
          </div>
          <p class="expert-desc">Math and science support for school students with concept-focused teaching.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 600<span>/hour</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="tutor" data-price="500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=400" class="expert-img" alt="Tutor">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">English Tutor</span>
          <h3 class="expert-name">Priyanka Sood</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (60)</span>
            <span>• 2.0 km away</span>
          </div>
          <p class="expert-desc">Spoken English, grammar improvement, and school-level language coaching.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 500<span>/hour</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="tutor" data-price="700">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=400" class="expert-img" alt="Tutor">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Private Tutor</span>
          <h3 class="expert-name">Rahul Bansal</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (49)</span>
            <span>• 3.0 km away</span>
          </div>
          <p class="expert-desc">Class 8 to 12 subject support with exam prep and practice planning.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 700<span>/hour</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- DRIVERS -->
      <div class="expert-card" data-cat="driver" data-price="1000">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=400" class="expert-img" alt="Driver">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Driver</span>
          <h3 class="expert-name">Gurpreet Singh</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (73)</span>
            <span>• 1.6 km away</span>
          </div>
          <p class="expert-desc">Local and outstation driving support with strong route familiarity.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,000<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="driver" data-price="1200">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=400" class="expert-img" alt="Driver">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Personal Driver</span>
          <h3 class="expert-name">Manpreet Gill</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (66)</span>
            <span>• 2.2 km away</span>
          </div>
          <p class="expert-desc">Full-day personal driving support for city errands and office travel.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,200<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="driver" data-price="1400">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=400" class="expert-img" alt="Driver">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Outstation Driver</span>
          <h3 class="expert-name">Harpreet Sandhu</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (54)</span>
            <span>• 3.8 km away</span>
          </div>
          <p class="expert-desc">Long-distance route handling, family travel, and late evening pickup support.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,400<span>/day</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <!-- BEAUTICIANS -->
      <div class="expert-card" data-cat="beautician" data-price="1500">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=400" class="expert-img" alt="Beautician">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Beautician</span>
          <h3 class="expert-name">Simran Kaur</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.9 (81)</span>
            <span>• 1.4 km away</span>
          </div>
          <p class="expert-desc">Makeup, hair styling, and home salon support for daily and event needs.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,500<span>/session</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="beautician" data-price="1300">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=400" class="expert-img" alt="Beautician">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Makeup Artist</span>
          <h3 class="expert-name">Ayesha Khan</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.8 (59)</span>
            <span>• 2.5 km away</span>
          </div>
          <p class="expert-desc">Party makeup, light glam looks, and skin prep from the comfort of home.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,300<span>/session</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

      <div class="expert-card" data-cat="beautician" data-price="1700">
        <div class="expert-img-wrapper">
          <img src="https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=400" class="expert-img" alt="Beautician">
          <div class="badge-status"><div class="dot"></div> Online</div>
        </div>
        <div class="expert-info">
          <span class="category-tag">Salon at Home</span>
          <h3 class="expert-name">Pooja Arora</h3>
          <div class="expert-meta">
            <span class="rating">★ 4.7 (46)</span>
            <span>• 3.3 km away</span>
          </div>
          <p class="expert-desc">Waxing, facial, grooming packages, and pre-event beauty sessions.</p>
        </div>
        <div class="expert-price-section">
          <div class="price-val">Rs. 1,700<span>/session</span></div>
          <button type="button" class="book-now-btn" onclick="goToProfile()">Book Now</button>
        </div>
      </div>

    </div>

    <div class="empty-state" id="emptyState">
      No experts match your selected filters.
    </div>
  </main>
</div>

<div class="mobile-filter-overlay" id="mobileFilterOverlay" onclick="closeMobileFilters()"></div>

<div class="mobile-filter-drawer" id="mobileFilterDrawer">
  <div class="drawer-handle"></div>
  <div class="drawer-head">
    <h3>Filter Experts</h3>
    <button type="button" class="drawer-close" onclick="closeMobileFilters()">Close</button>
  </div>

  <div class="filter-section">
    <h4>Categories</h4>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="cook" checked> Cooks</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="cleaner" checked> Cleaners</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="electrician" checked> Electricians</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="plumber" checked> Plumbers</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="babysitter" checked> Babysitters</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="tutor" checked> Tutors</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="driver" checked> Drivers</label>
    <label class="filter-item"><input type="checkbox" class="mobile-cat-filter" value="beautician" checked> Beauticians</label>
  </div>

  <div class="filter-section">
    <h4>Budget</h4>
    <label class="filter-item"><input type="radio" name="mobile-budget" value="all" checked> Show All</label>
    <label class="filter-item"><input type="radio" name="mobile-budget" value="low"> Under Rs. 2,000</label>
    <label class="filter-item"><input type="radio" name="mobile-budget" value="high"> Rs. 2,000 and above</label>
  </div>

  <div class="drawer-actions">
    <button type="button" class="drawer-btn secondary" onclick="resetMobileFilters()">Reset</button>
    <button type="button" class="drawer-btn primary" onclick="applyMobileFilters()">Apply Filters</button>
  </div>
</div>

<script>
function goToProfile() {
  window.location.href = "{{ route('profile') }}";
}

function getDesktopSelectedCats() {
  return Array.from(document.querySelectorAll('.sidebar .cat-filter:checked')).map(el => el.value);
}

function getDesktopBudget() {
  return document.querySelector('.sidebar input[name="budget"]:checked').value;
}

function updateList() {
  const selectedCats = getDesktopSelectedCats();
  const budgetFilter = getDesktopBudget();
  const cards = document.querySelectorAll('.expert-card');
  const emptyState = document.getElementById('emptyState');
  const resultsCount = document.getElementById('resultsCount');
  const resultsCountBadge = document.getElementById('resultsCountBadge');
  let visibleCount = 0;

  cards.forEach(card => {
    const cat = card.dataset.cat;
    const price = parseInt(card.dataset.price, 10);

    let show = selectedCats.includes(cat);

    if (budgetFilter === 'low' && price >= 2000) show = false;
    if (budgetFilter === 'high' && price < 2000) show = false;

    if (show) {
      card.classList.remove('hidden');
      visibleCount++;
    } else {
      card.classList.add('hidden');
    }
  });

  emptyState.classList.toggle('show', visibleCount === 0);
  if (resultsCount) resultsCount.textContent = visibleCount;
  if (resultsCountBadge) resultsCountBadge.textContent = `${visibleCount} match${visibleCount === 1 ? '' : 'es'}`;
  syncMobileQuickPills(selectedCats);
}

function sortData(order) {
  const container = document.getElementById('expert-container');
  const items = Array.from(container.querySelectorAll('.expert-card'));

  if (order === 'default') return;

  items.sort((a, b) => {
    const pA = parseInt(a.dataset.price, 10);
    const pB = parseInt(b.dataset.price, 10);
    return order === 'low' ? pA - pB : pB - pA;
  });

  items.forEach(item => container.appendChild(item));
}

function openMobileFilters() {
  document.getElementById('mobileFilterOverlay').classList.add('show');
  document.getElementById('mobileFilterDrawer').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeMobileFilters() {
  document.getElementById('mobileFilterOverlay').classList.remove('show');
  document.getElementById('mobileFilterDrawer').classList.remove('show');
  document.body.style.overflow = '';
}

function applyMobileFilters() {
  const mobileCats = Array.from(document.querySelectorAll('.mobile-cat-filter:checked')).map(el => el.value);
  const mobileBudget = document.querySelector('input[name="mobile-budget"]:checked').value;

  document.querySelectorAll('.sidebar .cat-filter').forEach(input => {
    input.checked = mobileCats.includes(input.value);
  });

  document.querySelectorAll('.sidebar input[name="budget"]').forEach(input => {
    input.checked = input.value === mobileBudget;
  });

  updateList();
  closeMobileFilters();
}

function resetMobileFilters() {
  document.querySelectorAll('.mobile-cat-filter').forEach(input => {
    input.checked = true;
  });
  document.querySelector('input[name="mobile-budget"][value="all"]').checked = true;
}

function selectMobileCategory(category, button) {
  document.querySelectorAll('.mobile-pill').forEach(p => p.classList.remove('active'));
  button.classList.add('active');

  const desktopInputs = document.querySelectorAll('.sidebar .cat-filter');
  const mobileInputs = document.querySelectorAll('.mobile-cat-filter');

  if (category === 'all') {
    desktopInputs.forEach(input => input.checked = true);
    mobileInputs.forEach(input => input.checked = true);
  } else {
    desktopInputs.forEach(input => input.checked = input.value === category);
    mobileInputs.forEach(input => input.checked = input.value === category);
  }

  document.querySelector('.sidebar input[name="budget"][value="all"]').checked = true;
  document.querySelector('input[name="mobile-budget"][value="all"]').checked = true;

  updateList();
}

function syncMobileQuickPills(selectedCats) {
  document.querySelectorAll('.mobile-pill').forEach(p => p.classList.remove('active'));

  if (selectedCats.length === 8) {
    const allPill = document.querySelector('.mobile-pill[data-cat="all"]');
    if (allPill) allPill.classList.add('active');
    return;
  }

  if (selectedCats.length === 1) {
    const matchingPill = document.querySelector(`.mobile-pill[data-cat="${selectedCats[0]}"]`);
    if (matchingPill) matchingPill.classList.add('active');
  }
}

document.addEventListener('DOMContentLoaded', function () {
  updateList();
});
</script>
@endsection
