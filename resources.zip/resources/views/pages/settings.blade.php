<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomeEase | Account Settings</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #7C3AED;
            --primary-light: #F5F3FF;
            --dark: #0F172A;
            --gray: #64748B;
            --white: #FFFFFF;
            --border: #F1F5F9;
            --bg: #FBFAFF;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: var(--bg); color: var(--dark); }

        /* --- Global Navigation --- */
        nav {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(15px);
            padding: 1rem 8%;
            position: sticky; top: 0; z-index: 1000;
            border-bottom: 1px solid var(--border);
            display: flex; justify-content: space-between; align-items: center;
        }
        .logo { font-size: 1.5rem; font-weight: 800; color: var(--primary); text-decoration: none; letter-spacing: -1px; }
        .nav-links { display: flex; gap: 25px; align-items: center; }
        .nav-links a { text-decoration: none; color: var(--dark); font-weight: 600; font-size: 0.9rem; }
        .user-pill { display: flex; align-items: center; gap: 10px; background: var(--primary-light); padding: 5px 15px; border-radius: 50px; color: var(--primary); font-weight: 700; }

        /* --- Settings Layout --- */
        .settings-wrapper {
            max-width: 1000px;
            margin: 50px auto;
            padding: 0 5%;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 50px;
        }

        .settings-nav { display: flex; flex-direction: column; gap: 10px; }
        .nav-btn {
            padding: 15px 20px; text-decoration: none; color: var(--gray);
            font-weight: 700; font-size: 0.95rem; border-radius: 15px;
            transition: 0.3s;
        }
        .nav-btn:hover { background: var(--primary-light); color: var(--primary); }
        .nav-btn.active { background: var(--white); color: var(--primary); box-shadow: 0 4px 12px rgba(0,0,0,0.03); }

        /* --- Content Sections --- */
        .settings-card {
            background: var(--white);
            padding: 40px;
            border-radius: 35px;
            border: 1px solid var(--border);
            box-shadow: 0 10px 30px rgba(0,0,0,0.02);
        }

        .section-h { font-size: 1.5rem; font-weight: 800; margin-bottom: 30px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
        .input-group { display: flex; flex-direction: column; gap: 8px; }
        .input-group label { font-size: 0.8rem; font-weight: 800; color: var(--gray); text-transform: uppercase; }
        .input-group input {
            padding: 14px; border-radius: 12px; border: 1.5px solid var(--border);
            outline: none; font-size: 1rem; transition: 0.3s;
        }
        .input-group input:focus { border-color: var(--primary); }

        /* --- Address Cards --- */
        .address-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 20px; border: 1.5px solid var(--border); border-radius: 20px;
            margin-bottom: 15px;
        }
        .address-info h4 { font-weight: 800; font-size: 1rem; }
        .address-info p { font-size: 0.85rem; color: var(--gray); }

        .btn-save {
            background: var(--primary); color: white; border: none;
            padding: 16px 40px; border-radius: 16px; font-weight: 800;
            cursor: pointer; transition: 0.3s; margin-top: 20px;
        }
        .btn-save:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(124, 58, 237, 0.2); }

        @media (max-width: 850px) {
            .settings-wrapper { grid-template-columns: 1fr; }
            .settings-nav { flex-direction: row; overflow-x: auto; padding-bottom: 10px; }
            .nav-btn { white-space: nowrap; }
        }
    </style>
</head>
<body>

@include('layouts.header')

    <div class="settings-wrapper">
        <aside class="settings-nav">
            <a href="#" class="nav-btn active">Personal Info</a>
            <a href="#" class="nav-btn">Saved Addresses</a>
            <a href="#" class="nav-btn">Payment Methods</a>
            <a href="#" class="nav-btn">Password & Security</a>
            <a href="#" class="nav-btn" style="color: #EF4444; margin-top: 20px;">Delete Account</a>
        </aside>

        <main class="settings-card">
            <h2 class="section-h">Personal Information</h2>
            
            <div class="form-row">
                <div class="input-group">
                    <label>First Name</label>
                    <input type="text" value="Alex">
                </div>
                <div class="input-group">
                    <label>Last Name</label>
                    <input type="text" value="Johnson">
                </div>
            </div>

            <div class="input-group" style="margin-bottom: 25px;">
                <label>Email Address</label>
                <input type="email" value="alex.j@example.com">
            </div>

            <div class="input-group" style="margin-bottom: 40px;">
                <label>Phone Number</label>
                <input type="tel" value="+91 98765 43210">
            </div>

            <h2 class="section-h">Saved Addresses</h2>
            
            <div class="address-item">
                <div class="address-info">
                    <h4>Home</h4>
                    <p>Sector 67, Mohali, Punjab - 160062</p>
                </div>
                <button style="background: none; border: none; color: var(--primary); font-weight: 700; cursor: pointer;">Edit</button>
            </div>

            <div class="address-item">
                <div class="address-info">
                    <h4>Work</h4>
                    <p>QuarkCity Office, Phase 8B, Mohali</p>
                </div>
                <button style="background: none; border: none; color: var(--primary); font-weight: 700; cursor: pointer;">Edit</button>
            </div>

            <button class="btn-save" onclick="alert('Profile Updated Successfully!')">Save Changes</button>
        </main>
    </div>

</body>
</html>