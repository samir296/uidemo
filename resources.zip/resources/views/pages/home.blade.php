﻿@extends('layouts.app')

@section('title', 'HomeEase | Local Experts On-Demand')

@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<style>
  @media (max-width: 560px) {
    .mobile-shortcuts {
        padding: 0 1rem 0.9rem;
    }
  }
  .card.hidden {
  display: none;
}
  :root {
    --primary: #7C3AED;
    --primary-light: #F5F3FF;
    --accent: #C4B5FD;
    --success: #10B981;
    --dark: #0F172A;
    --gray: #64748B;
    --white: #FFFFFF;
    --border: #E2E8F0;
    --bg-soft: #F8FAFC;
  }

  .hero {
    padding: 22px 8% 38px;
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(320px, 0.9fr);
    align-items: center;
    gap: 32px;
    background:
      radial-gradient(circle at top left, rgba(124, 58, 237, 0.18), transparent 28%),
      linear-gradient(180deg, #FCFBFF 0%, #F5F3FF 100%);
  }

  .hero-copy {
    display: grid;
    gap: 18px;
  }

  .hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    width: fit-content;
    padding: 10px 14px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.92);
    border: 1px solid rgba(124, 58, 237, 0.14);
    color: var(--primary);
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .hero-content h1 {
    font-size: clamp(2.25rem, 5vw, 4rem);
    line-height: 0.98;
    margin: 0;
    letter-spacing: -0.06em;
    max-width: 11ch;
  }

  .hero-content h1 span {
    color: var(--primary);
  }

  .hero-content p {
    color: var(--gray);
    margin: 0;
    font-size: clamp(1rem, 2vw, 1.08rem);
    line-height: 1.7;
    max-width: 58ch;
  }

  .hero-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
  }

  .hero-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 14px 18px;
    border-radius: 18px;
    font-weight: 800;
    text-decoration: none;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .hero-link.primary {
    background: linear-gradient(135deg, var(--primary), #8B5CF6);
    color: var(--white);
    box-shadow: 0 16px 34px rgba(124, 58, 237, 0.24);
  }

  .hero-link.secondary {
    background: rgba(255, 255, 255, 0.92);
    color: var(--dark);
    border: 1px solid var(--border);
  }

  .hero-link:hover {
    transform: translateY(-2px);
  }

  .hero-metrics {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
  }

  .metric-card {
    background: rgba(255, 255, 255, 0.94);
    border: 1px solid rgba(226, 232, 240, 0.95);
    border-radius: 22px;
    padding: 16px;
  }

  .metric-card strong {
    display: block;
    font-size: 1.45rem;
    margin-bottom: 4px;
    color: var(--dark);
  }

  .metric-card span {
    color: var(--gray);
    font-size: 0.84rem;
    font-weight: 600;
  }

  .search-container {
    background: var(--white);
    padding: 10px;
    border-radius: 28px;
    display: grid;
    grid-template-columns: minmax(120px, 180px) 1fr auto;
    align-items: center;
    box-shadow: 0 20px 40px rgba(124, 58, 237, 0.1);
    max-width: 720px;
    border: 1px solid rgba(226, 232, 240, 0.9);
  }

  .location-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 52px;
    padding: 0 14px;
    border-right: 1px solid #F1F5F9;
    cursor: pointer;
    color: var(--primary);
    transition: 0.3s;
  }

  .location-btn:hover {
    opacity: 0.7;
  }

  .location-btn span {
    font-size: 0.85rem;
    font-weight: 700;
    white-space: nowrap;
  }

  .search-container input {
    width: 100%;
    border: none;
    padding: 15px;
    outline: none;
    font-size: 1rem;
    min-height: 52px;
  }

  .search-container button {
    background: var(--primary);
    color: white;
    border: none;
    padding: 14px 22px;
    border-radius: 18px;
    font-weight: 700;
    cursor: pointer;
    min-height: 52px;
  }

  .hero-panel {
    background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
    border: 1px solid rgba(226, 232, 240, 0.95);
    border-radius: 32px;
    padding: 20px;
    box-shadow: 0 26px 60px rgba(15, 23, 42, 0.08);
  }

  .panel-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
  }

  .panel-head h3 {
    font-size: 1.05rem;
    margin: 0;
  }

  .panel-chip {
    padding: 8px 12px;
    border-radius: 999px;
    background: #ECFDF5;
    color: #047857;
    font-size: 0.76rem;
    font-weight: 800;
  }

  .panel-stack {
    display: grid;
    gap: 14px;
  }

  .panel-card {
    display: grid;
    grid-template-columns: 64px 1fr auto;
    gap: 14px;
    align-items: center;
    padding: 14px;
    border-radius: 22px;
    background: #FFFFFF;
    border: 1px solid #EEF2FF;
  }

  .panel-card img {
    width: 64px;
    height: 64px;
    object-fit: cover;
    border-radius: 18px;
  }

  .panel-card h4 {
    margin: 0 0 4px;
    font-size: 1rem;
  }

  .panel-card p {
    margin: 0;
    color: var(--gray);
    font-size: 0.84rem;
  }

  .panel-price {
    text-align: right;
  }

  .panel-price strong {
    display: block;
    color: var(--primary);
    font-size: 1rem;
  }

  .panel-price span {
    color: var(--gray);
    font-size: 0.8rem;
  }

  .trust-section {
    padding: 0 8% 18px;
  }

  .trust-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
  }

  .trust-card {
    background: var(--white);
    border: 1px solid var(--border);
    border-radius: 24px;
    padding: 18px;
  }

  .trust-card h3 {
    margin: 0 0 6px;
    font-size: 1rem;
  }

  .trust-card p {
    margin: 0;
    color: var(--gray);
    line-height: 1.6;
    font-size: 0.88rem;
  }

  .filter-wrapper {
    padding: 14px 8% 12px;
    position: sticky;
    top: 0;
    z-index: 999;
    background: rgba(252, 251, 255, 0.9);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  }

  .filter-shell {
    max-width: 1240px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.92);
    border: 1px solid rgba(226, 232, 240, 0.95);
    border-radius: 28px;
    padding: 16px;
    box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
  }

  .filter-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
  }

  .filter-label {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .filter-label strong {
    font-size: 0.98rem;
    color: var(--dark);
  }

  .filter-label span {
    font-size: 0.84rem;
    color: var(--gray);
  }

  .filter-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    padding: 8px 12px;
    border-radius: 999px;
    background: var(--primary-light);
    color: var(--primary);
    font-size: 0.82rem;
    font-weight: 800;
  }

  .filter-container {
    display: flex;
    gap: 12px;
    overflow-x: auto;
    scrollbar-width: none;
    padding-bottom: 4px;
    scroll-snap-type: x proximity;
  }

  .filter-container::-webkit-scrollbar {
    display: none;
  }

  .filter-btn {
    padding: 12px 20px;
    border-radius: 50px;
    border: 1px solid var(--border);
    background: #F8FAFC;
    font-weight: 700;
    cursor: pointer;
    white-space: nowrap;
    transition: 0.3s;
    color: var(--gray);
    scroll-snap-align: start;
  }

  .filter-btn.active {
    background: var(--primary);
    color: var(--white);
    border-color: var(--primary);
    box-shadow: 0 10px 20px rgba(124, 58, 237, 0.2);
  }

  .marketplace {
    padding: 36px 8% 40px;
  }

  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    gap: 12px;
  }

  .view-all {
    color: var(--primary);
    text-decoration: none;
    font-weight: 700;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.4rem;
  }

  .card {
    background: var(--white);
    border-radius: 24px;
    overflow: hidden;
    border: 1px solid #F1F5F9;
    transition: 0.4s;
    position: relative;
    text-decoration: none;
    color: inherit;
    display: block;
  }

  .card.hidden {
    display: none;
  }

  .card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.05);
  }

  .status-pill {
    position: absolute;
    top: 15px;
    left: 15px;
    background: rgba(255, 255, 255, 0.9);
    padding: 5px 12px;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--success);
  }

  .card-img {
    width: 100%;
    height: 220px;
    object-fit: cover;
  }

  .card-body {
    padding: 1.5rem;
  }

  .mini-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin: 10px 0 0;
  }

  .mini-meta span {
    padding: 6px 10px;
    border-radius: 999px;
    background: #F8FAFC;
    color: var(--gray);
    font-size: 0.76rem;
    font-weight: 700;
  }

  .category-tag {
    color: var(--primary);
    font-size: 0.75rem;
    font-weight: 800;
    text-transform: uppercase;
  }

  .name {
    font-size: 1.3rem;
    font-weight: 700;
    margin: 5px 0;
  }

  .card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
    border-top: 1px solid #f1f1f1;
    padding-top: 1rem;
  }

  .price {
    font-weight: 800;
    font-size: 1.1rem;
    color: var(--dark);
  }

  .book-btn {
    background: var(--primary);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 12px;
    font-weight: 700;
    cursor: pointer;
  }

  .extra-section,
 
  .testimonials {
    padding: 24px 8% 48px;
    background: var(--white);
  }

  .,
  .testimonials-header,
  .extra-header {
    margin-bottom: 1.6rem;
    text-align: center;
  }

  .static-cards {
  padding: 60px 20px;
  background: #f9fafb;
  text-align: center;
}

.static-section-header h2 {
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 10px;
}

.static-section-header p {
  color: #6c757d;
  margin-bottom: 40px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 25px;
}

.static-card {
  background: #ffffff;
  padding: 30px 20px;
  border-radius: 16px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.static-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
}

.card-icon {
  font-size: 50px;
  /* color: #2F9C95; Adjust to match your theme */
  margin-bottom: 20px;
  display: inline-block;
}

.static-card h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 10px;
}

.static-card p {
  font-size: 0.95rem;
  color: #6c757d;
}

  .extra-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
  }

  .extra-card {
    border: 1px solid var(--border);
    border-radius: 24px;
    padding: 22px;
    background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
  }

  .extra-card h3 {
    margin: 0 0 10px;
    font-size: 1rem;
  }

  .extra-card p,
  .extra-card li {
    color: var(--gray);
    line-height: 1.6;
    font-size: 0.92rem;
  }

  .extra-card ul {
    margin: 0;
    padding-left: 18px;
  }

  .testimonial-card {
    background: linear-gradient(180deg, #FFFFFF 0%, var(--primary-light) 100%);
    border-radius: 20px;
    padding: 22px;
    margin: 0;
    border: 1px solid rgba(226, 232, 240, 0.95);
    transition: transform 0.3s;
  }

  .testimonial-text {
    font-style: italic;
    color: var(--gray);
  }

  .testimonial-author {
    font-weight: bold;
    margin-top: 10px;
  }

  @media (max-width: 1100px) {
    .hero,
    .trust-grid,
    .extra-grid,
    .hero-metrics {
      grid-template-columns: 1fr 1fr;
    }
  }

  @media (max-width: 900px) {
    .hero {
      grid-template-columns: 1fr;
      padding-top: 18px;
      gap: 22px;
    }

    .hero-content h1 {
      max-width: 100%;
    }

    .search-container {
      grid-template-columns: 1fr;
      gap: 10px;
      padding: 12px;
    }

    .location-btn {
      border-right: none;
      border-bottom: 1px solid #F1F5F9;
      justify-content: flex-start;
      padding: 0 6px 10px;
      min-height: auto;
    }

    .search-container button {
      width: 100%;
    }

    .trust-grid,
    .extra-grid,
    .hero-metrics {
      grid-template-columns: 1fr;
    }

    .section-header {
      flex-direction: column;
      align-items: flex-start;
    }
  }

  @media (max-width: 640px) {
    .hero {
      padding: 14px 5% 28px;
    }

    .hero-panel,
    .trust-section {
      display: none;
    }

    .marketplace,
    .trust-section,
    .extra-section,
    .static-cards,
    .testimonials,
    .filter-wrapper {
      padding-left: 5%;
      padding-right: 5%;
    }

    .filter-shell {
      border-radius: 24px;
      padding: 14px;
    }

    #provider-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }

    .filter-header {
      flex-direction: column;
      align-items: flex-start;
      margin-bottom: 10px;
    }

    .filter-status {
      min-height: 36px;
      font-size: 0.78rem;
    }

    .panel-card {
      grid-template-columns: 56px 1fr;
    }

    .panel-price {
      grid-column: 2;
      text-align: left;
    }

    .card-img {
      height: 140px;
    }

    .card-body,
    .trust-card,
    .extra-card,
    .static-card,
    .testimonial-card {
      padding: 18px;
    }

    .card-footer {
      flex-direction: column;
      align-items: flex-start;
      gap: 10px;
      margin-top: 0.85rem;
      padding-top: 0.85rem;
    }

    #provider-grid .card-body {
      padding: 14px;
    }

    #provider-grid .name {
      font-size: 1rem;
      line-height: 1.3;
    }

    #provider-grid .mini-meta {
      gap: 6px;
      margin-top: 8px;
    }

    #provider-grid .mini-meta span {
      padding: 5px 8px;
      font-size: 0.68rem;
    }

    #provider-grid .price {
      font-size: 0.95rem;
    }

    .book-btn {
      width: 100%;
      padding: 9px 14px;
      font-size: 0.86rem;
    }
  }

  @media (max-width: 560px) {
    .filter-wrapper {
      top: 0;
      padding-top: 10px;
    }

    .filter-shell {
      border-radius: 22px;
      padding: 12px;
    }

    .filter-label strong {
      font-size: 0.92rem;
    }

    .filter-label span {
      font-size: 0.78rem;
    }

    .filter-container {
      gap: 8px;
    }

    .filter-btn {
      padding: 10px 16px;
      font-size: 0.84rem;
    }
  }

  @media (max-width: 420px) {
    #provider-grid {
      grid-template-columns: 1fr;
    }
  }
</style>

<header class="hero">
  <div class="hero-copy">
    <div class="hero-badge">HomeEase App Experience</div>
    <div class="hero-content">
      <h1>Book trusted home help in <span>minutes</span>.</h1>
      <p>Find cooks, cleaners, electricians, plumbers, babysitters, tutors, drivers, and beauticians near you with an app-like browsing experience built for mobile users first.</p>
    </div>

    <div class="search-container">
      <div class="location-btn" onclick="detectLocation()" tabindex="0" role="button">
        <span>Near You</span>
        <span id="loc-text">Detect Location</span>
      </div>
      <input type="text" id="hero-search-input" placeholder="Search cooks, cleaners, repair experts, tutors, babysitters, or drivers">
      <button type="button" id="hero-search-btn" onclick="runHeroSearch()">Search</button>
    </div>

    <div class="hero-actions">
      <a href="{{ route('register', ['role' => 'user']) }}" class="hero-link primary">Find Help</a>
      <a href="{{ route('register', ['role' => 'provider']) }}" class="hero-link secondary">Become a Provider</a>
    </div>

    <div class="hero-metrics">
      <div class="metric-card">
        <strong>2,500+</strong>
        <span>Verified local experts</span>
      </div>
      <div class="metric-card">
        <strong>18 min</strong>
        <span>Average response time</span>
      </div>
      <div class="metric-card">
        <strong>4.8/5</strong>
        <span>Average service rating</span>
      </div>
    </div>
  </div>

  <aside class="hero-panel">
    <div class="panel-head">
      <h3>Popular near you</h3>
      <span class="panel-chip">Live now</span>
    </div>

    <div class="panel-stack">
      <div class="panel-card">
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=300" alt="Cook">
        <div>
          <h4>Riya Sharma</h4>
          <p>Home cook in Sector 62, Mohali</p>
        </div>
        <div class="panel-price">
          <strong>Rs. 1,800</strong>
          <span>per day</span>
        </div>
      </div>

      <div class="panel-card">
        <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=300" alt="Cleaner">
        <div>
          <h4>Amit Singh</h4>
          <p>Deep cleaning and sanitation support</p>
        </div>
        <div class="panel-price">
          <strong>Rs. 1,200</strong>
          <span>per visit</span>
        </div>
      </div>

      <div class="panel-card">
        <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=300" alt="Electrician">
        <div>
          <h4>Vikram Jha</h4>
          <p>Electric repair and installation</p>
        </div>
        <div class="panel-price">
          <strong>Rs. 2,000</strong>
          <span>per visit</span>
        </div>
      </div>
    </div>
  </aside>
</header>

<section class="trust-section">
  <div class="trust-grid">
    <div class="trust-card">
      <h3>Quick booking flow</h3>
      <p>Customers can discover, compare, and request help from one screen without getting lost in long forms.</p>
    </div>
    <div class="trust-card">
      <h3>Mobile-first layout</h3>
      <p>Large touch targets, stacked cards, and simplified search make the site feel closer to a service app on phones.</p>
    </div>
    <div class="trust-card">
      <h3>Local pricing in rupees</h3>
      <p>Prices now read in INR so the marketplace feels natural for Indian users and more conversion-friendly.</p>
    </div>
    <div class="trust-card">
      <h3>More trust signals</h3>
      <p>Added richer service details, ratings, and delivery promises to help new users feel comfortable booking faster.</p>
    </div>
  </div>
</section>

<div class="filter-wrapper">
  <div class="filter-shell">
    <div class="filter-header">
      <div class="filter-label">
        <strong>Browse by service</strong>
        <span>Quick app-style filters for nearby experts</span>
      </div>
      <div class="filter-status" id="filter-status">24 experts live</div>
    </div>
    <div class="filter-container">
      <button class="filter-btn active" onclick="filterServices('all', this)">All Services</button>
      <button class="filter-btn" onclick="filterServices('cook', this)">Cooks</button>
      <button class="filter-btn" onclick="filterServices('cleaner', this)">Cleaners</button>
      <button class="filter-btn" onclick="filterServices('electrician', this)">Electricians</button>
      <button class="filter-btn" onclick="filterServices('plumber', this)">Plumbers</button>
      <button class="filter-btn" onclick="filterServices('babysitter', this)">Babysitters</button>
      <button class="filter-btn" onclick="filterServices('tutor', this)">Tutors</button>
      <button class="filter-btn" onclick="filterServices('driver', this)">Drivers</button>
      <button class="filter-btn" onclick="filterServices('beautician', this)">Beauticians</button>
    </div>
  </div>
</div>

<main class="marketplace">
  <div class="section-header">
    <h2 id="service-title">All Available Experts</h2>
    <a href="/list" class="view-all">View Full List</a>
  </div>

  <p id="search-feedback" style="display:none; margin: -0.75rem 0 1.25rem; color: var(--gray); font-weight: 600;"></p>

  <div class="grid" id="provider-grid">

    <!-- COOKS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="cook">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=500" class="card-img" alt="Home Cook">
        <div class="card-body">
          <span class="category-tag">Home Cook</span>
          <h3 class="name">Riya Sharma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 62, Mohali</p>
          <div class="mini-meta">
            <span>4.9 rating</span>
            <span>120+ bookings</span>
            <span>Meal prep</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,800<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="cook">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=500" class="card-img" alt="Cook">
        <div class="card-body">
          <span class="category-tag">North Indian Cook</span>
          <h3 class="name">Sunita Verma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 45, Chandigarh</p>
          <div class="mini-meta">
            <span>Veg & Non-Veg</span>
            <span>4.8 rating</span>
            <span>80+ bookings</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,600<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="cook">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500" class="card-img" alt="Chef">
        <div class="card-body">
          <span class="category-tag">Specialty Chef</span>
          <h3 class="name">Arjun Mehta</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Kharar, Mohali</p>
          <div class="mini-meta">
            <span>Party orders</span>
            <span>4.9 rating</span>
            <span>Premium meals</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 2,500<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- CLEANERS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="cleaner">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1581578731548-c64695cc6954?auto=format&fit=crop&w=500" class="card-img" alt="Cleaner">
        <div class="card-body">
          <span class="category-tag">Deep Cleaning</span>
          <h3 class="name">Amit Singh</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 15, Chandigarh</p>
          <div class="mini-meta">
            <span>4.7 rating</span>
            <span>Same-day slot</span>
            <span>Tools included</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,200<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="cleaner">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?auto=format&fit=crop&w=500" class="card-img" alt="Cleaner">
        <div class="card-body">
          <span class="category-tag">Home Cleaning</span>
          <h3 class="name">Pooja Sharma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Zirakpur</p>
          <div class="mini-meta">
            <span>Eco-friendly</span>
            <span>4.8 rating</span>
            <span>100+ jobs</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,000<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="cleaner">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=500" class="card-img" alt="Office Cleaner">
        <div class="card-body">
          <span class="category-tag">Office Cleaning</span>
          <h3 class="name">Rakesh Kumar</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Mohali</p>
          <div class="mini-meta">
            <span>Commercial spaces</span>
            <span>4.7 rating</span>
            <span>Flexible timing</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,500<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- ELECTRICIANS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="electrician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=500" class="card-img" alt="Electrician">
        <div class="card-body">
          <span class="category-tag">Electrician</span>
          <h3 class="name">Rajesh Kumar</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Phase 7, Mohali</p>
          <div class="mini-meta">
            <span>4.8 rating</span>
            <span>150+ jobs</span>
            <span>24/7 service</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 500<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="electrician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=500" class="card-img" alt="Electric Repair">
        <div class="card-body">
          <span class="category-tag">Electric Repair</span>
          <h3 class="name">Vikram Jha</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 71, Mohali</p>
          <div class="mini-meta">
            <span>Wiring expert</span>
            <span>4.9 rating</span>
            <span>Fan fitting</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 700<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="electrician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1555963966-b7ae5404b6ed?auto=format&fit=crop&w=500" class="card-img" alt="Electrician Service">
        <div class="card-body">
          <span class="category-tag">Installation Expert</span>
          <h3 class="name">Deepak Yadav</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Chandigarh</p>
          <div class="mini-meta">
            <span>Switch boards</span>
            <span>4.7 rating</span>
            <span>Same day</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 650<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- PLUMBERS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="plumber">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=500" class="card-img" alt="Plumber">
        <div class="card-body">
          <span class="category-tag">Plumber</span>
          <h3 class="name">Sandeep Verma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Zirakpur, Punjab</p>
          <div class="mini-meta">
            <span>Leak repairs</span>
            <span>Same-day service</span>
            <span>4.7 rating</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 450<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="plumber">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1628744448840-55bdb2497bd4?auto=format&fit=crop&w=500" class="card-img" alt="Plumber Expert">
        <div class="card-body">
          <span class="category-tag">Bathroom Fittings</span>
          <h3 class="name">Mohit Sharma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 22, Chandigarh</p>
          <div class="mini-meta">
            <span>Tap fitting</span>
            <span>4.8 rating</span>
            <span>90+ visits</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 550<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="plumber">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=500" class="card-img" alt="Plumbing Service">
        <div class="card-body">
          <span class="category-tag">Pipe Repair</span>
          <h3 class="name">Ramesh Patel</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Kharar</p>
          <div class="mini-meta">
            <span>Pipe leaks</span>
            <span>4.6 rating</span>
            <span>Quick response</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 500<span>/visit</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- BABYSITTERS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="babysitter">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=500" class="card-img" alt="Babysitter">
        <div class="card-body">
          <span class="category-tag">Babysitter</span>
          <h3 class="name">Neha Gupta</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 70, Mohali</p>
          <div class="mini-meta">
            <span>Child care</span>
            <span>Verified</span>
            <span>4.9 rating</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 800<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="babysitter">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=500" class="card-img" alt="Child Care">
        <div class="card-body">
          <span class="category-tag">Child Care Expert</span>
          <h3 class="name">Kavita Sharma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Panchkula</p>
          <div class="mini-meta">
            <span>Infant care</span>
            <span>4.8 rating</span>
            <span>Certified</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 900<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="babysitter">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=crop&w=500" class="card-img" alt="Babysitting Service">
        <div class="card-body">
          <span class="category-tag">Nanny Service</span>
          <h3 class="name">Meera Joshi</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 34, Chandigarh</p>
          <div class="mini-meta">
            <span>Evening support</span>
            <span>4.7 rating</span>
            <span>Trusted</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 850<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- TUTORS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="tutor">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=500" class="card-img" alt="Home Tutor">
        <div class="card-body">
          <span class="category-tag">Home Tutor</span>
          <h3 class="name">Ankit Sharma</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 34, Chandigarh</p>
          <div class="mini-meta">
            <span>Math & Science</span>
            <span>5+ years exp.</span>
            <span>4.9 rating</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 600<span>/hour</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="tutor">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=500" class="card-img" alt="Tutor">
        <div class="card-body">
          <span class="category-tag">English Tutor</span>
          <h3 class="name">Priyanka Sood</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Mohali</p>
          <div class="mini-meta">
            <span>Spoken English</span>
            <span>4.8 rating</span>
            <span>Kids friendly</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 500<span>/hour</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="tutor">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=500" class="card-img" alt="Private Tutor">
        <div class="card-body">
          <span class="category-tag">Private Tutor</span>
          <h3 class="name">Rahul Bansal</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Zirakpur</p>
          <div class="mini-meta">
            <span>Class 8-12</span>
            <span>4.7 rating</span>
            <span>Exam prep</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 700<span>/hour</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- DRIVERS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="driver">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=500" class="card-img" alt="Driver">
        <div class="card-body">
          <span class="category-tag">Driver</span>
          <h3 class="name">Gurpreet Singh</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Panchkula</p>
          <div class="mini-meta">
            <span>Local & Outstation</span>
            <span>10+ years exp.</span>
            <span>4.8 rating</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,000<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="driver">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=500" class="card-img" alt="Car Driver">
        <div class="card-body">
          <span class="category-tag">Personal Driver</span>
          <h3 class="name">Manpreet Gill</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 17, Chandigarh</p>
          <div class="mini-meta">
            <span>Safe driving</span>
            <span>4.9 rating</span>
            <span>Full day trips</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,200<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="driver">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=500" class="card-img" alt="Driver Service">
        <div class="card-body">
          <span class="category-tag">Outstation Driver</span>
          <h3 class="name">Harpreet Sandhu</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Mohali</p>
          <div class="mini-meta">
            <span>Long route</span>
            <span>4.7 rating</span>
            <span>Night duty</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,400<span>/day</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <!-- BEAUTICIANS -->
    <a href="{{ route('profile') }}">
      <div class="card" data-category="beautician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=500" class="card-img" alt="Beautician">
        <div class="card-body">
          <span class="category-tag">Beautician</span>
          <h3 class="name">Simran Kaur</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Sector 21, Chandigarh</p>
          <div class="mini-meta">
            <span>Makeup & Hair</span>
            <span>Home service</span>
            <span>4.9 rating</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,500<span>/session</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="beautician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=500" class="card-img" alt="Beauty Service">
        <div class="card-body">
          <span class="category-tag">Makeup Artist</span>
          <h3 class="name">Ayesha Khan</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Zirakpur</p>
          <div class="mini-meta">
            <span>Party makeup</span>
            <span>4.8 rating</span>
            <span>Skin care</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,300<span>/session</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

    <a href="{{ route('profile') }}">
      <div class="card" data-category="beautician">
        <div class="status-pill"><div class="dot"></div> available</div>
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=500" class="card-img" alt="Beautician Expert">
        <div class="card-body">
          <span class="category-tag">Salon at Home</span>
          <h3 class="name">Pooja Arora</h3>
          <p style="color: var(--gray); font-size: 0.85rem;">Panchkula</p>
          <div class="mini-meta">
            <span>Waxing & facial</span>
            <span>4.7 rating</span>
            <span>Bridal prep</span>
          </div>
          <div class="card-footer">
            <div class="price">Rs. 1,700<span>/session</span></div>
            <button class="book-btn">Book</button>
          </div>
        </div>
      </div>
    </a>

  </div>
</main>

<section class="extra-section">
  <div class="extra-header">
    <h2>Why new users trust HomeEase faster</h2>
    <p>We added more decision-making information right on the landing page so mobile users can act quickly.</p>
  </div>

  <div class="extra-grid">
    <div class="extra-card">
      <h3>Top reasons people book</h3>
      <ul>
        <li>Daily cooking support for working families</li>
        <li>Weekend deep cleaning before guests arrive</li>
        <li>Urgent electrical and plumbing visits</li>
      </ul>
    </div>

    <div class="extra-card">
      <h3>What users care about most</h3>
      <ul>
        <li>Transparent local pricing in rupees</li>
        <li>Fast provider response on mobile</li>
        <li>Clear ratings, skills, and location details</li>
      </ul>
    </div>

    <div class="extra-card">
      <h3>How the app-like flow helps</h3>
      <p>Shorter reading paths, prominent actions, and stacked cards make it easier for phone users to browse and book with confidence.</p>
    </div>
  </div>
</section>

<section class="static-cards">
  <div class="static-section-header">
    <h2>Explore Our Services</h2>
    <p>Discover how we can help you with your daily tasks.</p>
  </div>

  <div class="grid">
    <!-- Home Cleaning -->
    <div class="static-card">
      <i class="bi bi-house-check card-icon"></i>
      <h3>Home Cleaning</h3>
      <p>Professional cleaning services to keep your home spotless and guest-ready.</p>
    </div>

    <!-- Cooking Services -->
    <div class="static-card">
      <i class="bi bi-egg-fried card-icon"></i>
      <h3>Cooking Services</h3>
      <p>Hire expert cooks for daily meals, family events, and diet-friendly kitchen support.</p>
    </div>

    <!-- Plumbing Services -->
    <div class="static-card">
      <i class="bi bi-tools card-icon"></i>
      <h3>Plumbing Services</h3>
      <p>Reliable plumbers for urgent leaks, fittings, bathroom repairs, and maintenance visits.</p>
    </div>

    <!-- Electrical Services -->
    <div class="static-card">
      <i class="bi bi-lightning-charge card-icon"></i>
      <h3>Electrical Services</h3>
      <p>Certified electricians for safe repairs, installations, fan fitting, and wiring support.</p>
    </div>
  </div>
</section>

<section class="testimonials">
  <div class="testimonials-header">
    <h2>What Our Customers Say</h2>
    <p>Read testimonials from satisfied users across Mohali and Chandigarh.</p>
  </div>
  <div class="grid">
    <div class="testimonial-card">
      <p class="testimonial-text">"HomeEase made my life so much easier. The cleaning service was professional and very quick to arrive."</p>
      <p class="testimonial-author">- Priya K.</p>
    </div>
    <div class="testimonial-card">
      <p class="testimonial-text">"I hired a cook through HomeEase and the meals were fantastic. The app-like flow was easy even on my phone."</p>
      <p class="testimonial-author">- Raj S.</p>
    </div>
    <div class="testimonial-card">
      <p class="testimonial-text">"The plumber was quick and efficient. Clear pricing in rupees made booking much more comfortable."</p>
      <p class="testimonial-author">- Anita R.</p>
    </div>
    <div class="testimonial-card">
      <p class="testimonial-text">"Great experience with the electricians. They were on time, skilled, and easy to connect with through HomeEase."</p>
      <p class="testimonial-author">- Vikram T.</p>
    </div>
  </div>
</section>

<script>
 
  let isDetectingLocation = false;
  let activeServiceCategory = 'all';
  let activeSearchQuery = '';

  async function resolveLocationName(latitude, longitude) {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`, {
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Reverse geocoding failed');
      }

      const data = await response.json();
      const address = data.address || {};
      const city = address.city || address.town || address.village || address.state_district || address.county;
      const state = address.state;

      if (city && state) {
        return `${city}, ${state}`;
      }

      return city || state || 'Current Location';
    } catch (error) {
      return 'Current Location';
    }
  }

  function detectLocation() {
    const text = document.getElementById('loc-text');
    if (!text || isDetectingLocation) return;

    if (!navigator.geolocation) {
      text.innerText = 'Location Unsupported';
      return;
    }

    isDetectingLocation = true;
    text.innerText = 'Finding you...';

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        const locationName = await resolveLocationName(latitude, longitude);
        text.innerText = locationName;
        isDetectingLocation = false;
      },
      () => {
        text.innerText = 'Enable Location';
        isDetectingLocation = false;
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000
      }
    );
  }

  function applyMarketplaceFilters() {
    const cards = document.querySelectorAll('#provider-grid .card');
    const title = document.getElementById('service-title');
    const filterStatus = document.getElementById('filter-status');
    const searchFeedback = document.getElementById('search-feedback');
    let visibleCount = 0;
    const normalizedQuery = activeSearchQuery.trim().toLowerCase();

    cards.forEach((card) => {
      const wrapper = card.closest('a');
      const cardCategory = card.getAttribute('data-category');
      const cardText = card.innerText.toLowerCase();
      const matchesCategory = activeServiceCategory === 'all' || cardCategory === activeServiceCategory;
      const matchesSearch = !normalizedQuery || cardText.includes(normalizedQuery);

      if (matchesCategory && matchesSearch) {
        wrapper.style.display = 'block';
        visibleCount++;
      } else {
        wrapper.style.display = 'none';
      }
    });

    const categoryNames = {
      cook: 'Cooks',
      cleaner: 'Cleaners',
      electrician: 'Electricians',
      plumber: 'Plumbers',
      babysitter: 'Babysitters',
      tutor: 'Tutors',
      driver: 'Drivers',
      beautician: 'Beauticians'
    };

    title.innerHTML = activeServiceCategory === 'all'
      ? 'All Available Experts'
      : `Available <span>${categoryNames[activeServiceCategory] || activeServiceCategory}</span>`;

    if (filterStatus) {
      filterStatus.textContent = `${visibleCount} expert${visibleCount === 1 ? '' : 's'} live`;
    }

    if (searchFeedback) {
      if (normalizedQuery) {
        searchFeedback.style.display = 'block';
        searchFeedback.textContent = `${visibleCount} result${visibleCount === 1 ? '' : 's'} for "${activeSearchQuery.trim()}"`;
      } else {
        searchFeedback.style.display = 'none';
        searchFeedback.textContent = '';
      }
    }
  }

  function filterServices(category, btn) {
    activeServiceCategory = category;

    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    applyMarketplaceFilters();
  }

  function runHeroSearch() {
    const input = document.getElementById('hero-search-input');
    const marketplace = document.querySelector('.marketplace');
    if (!input) return;

    activeSearchQuery = input.value || '';
    applyMarketplaceFilters();

    if (marketplace) {
      marketplace.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const activeButton = document.querySelector('.filter-btn.active');
    if (activeButton) {
      filterServices('all', activeButton);
    }

    const heroSearchInput = document.getElementById('hero-search-input');
    if (heroSearchInput) {
      heroSearchInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          runHeroSearch();
        }
      });
    }

    detectLocation();
  });

 
</script>
@endsection
