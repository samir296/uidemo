@extends('layouts.app')

@section('title', 'HomeEase | My Requests')

@section('content')
<style>
body {
  background:
    radial-gradient(circle at top left, rgba(124, 58, 237, 0.12), transparent 25%),
    linear-gradient(180deg, #FCFBFF 0%, #F8FAFC 100%);
}

.requests-shell {
  max-width: 980px;
  margin: 0 auto;
  padding: 1rem;
}

.panel {
  background: rgba(255,255,255,0.95);
  border: 1px solid rgba(226,232,240,0.96);
  border-radius: 28px;
  padding: clamp(1rem, 4vw, 1.4rem);
  box-shadow: 0 22px 55px rgba(15,23,42,0.06);
}

.request-list {
  display: grid;
  gap: 1rem;
  margin-top: 1rem;
}

.request-card {
  border: 1px solid #E2E8F0;
  border-radius: 22px;
  padding: 1rem;
  background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
}

.request-head {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  align-items: flex-start;
  margin-bottom: 0.7rem;
}

.request-head strong {
  display: block;
  color: #0F172A;
  margin-bottom: 0.25rem;
}

.request-card p {
  margin: 0;
  color: #64748B;
  line-height: 1.55;
}

.status {
  padding: 0.45rem 0.8rem;
  border-radius: 999px;
  font-size: 0.76rem;
  font-weight: 800;
}

.status.live {
  background: #ECFDF5;
  color: #047857;
}

.status.pending {
  background: #FEF3C7;
  color: #92400E;
}

.meta-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
  margin-top: 0.8rem;
}

.meta-row span {
  padding: 0.45rem 0.75rem;
  border-radius: 999px;
  background: #F5F3FF;
  color: #7C3AED;
  font-size: 0.76rem;
  font-weight: 800;
}

@media (max-width: 640px) {
  .requests-shell {
    padding: 0.85rem;
  }

  .panel,
  .request-card {
    border-radius: 22px;
    padding: 1rem;
  }

  .request-head {
    flex-direction: column;
  }
}
</style>

<div class="requests-shell">
  <div class="panel">
    <h1 style="margin:0;color:#0F172A;">My Requests</h1>
    <p style="color:#64748B;line-height:1.6;">Track active and past service requests in one clean mobile list.</p>

    <div class="request-list">
      <div class="request-card">
        <div class="request-head">
          <div>
            <strong>Home cleaning request</strong>
            <p>Scheduled for tomorrow morning with Amit Singh.</p>
          </div>
          <span class="status live">Confirmed</span>
        </div>
        <div class="meta-row">
          <span>Sector 15, Chandigarh</span>
          <span>9:00 AM</span>
          <span>Rs. 1,200</span>
        </div>
      </div>

      <div class="request-card">
        <div class="request-head">
          <div>
            <strong>Math tutoring request</strong>
            <p>Provider shortlist sent. Waiting for final schedule confirmation.</p>
          </div>
          <span class="status pending">Pending</span>
        </div>
        <div class="meta-row">
          <span>Online</span>
          <span>Weekday evenings</span>
          <span>Class 9</span>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
