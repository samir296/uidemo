@extends('layouts.app')

@section('title', 'HomeEase | Expert Profile')

@section('content')
<style>
:root {
  --primary: #7C3AED;
  --primary-light: #F5F3FF;
  --dark: #0F172A;
  --gray: #64748B;
  --white: #FFFFFF;
  --border: #E2E8F0;
  --success: #10B981;
  --bg: #FAFAFB;
}

.main-content {
  max-width: 1200px;
  margin: clamp(1rem, 5vw, 3rem) auto;
  padding: 0 clamp(1rem, 5vw, 5%);
  display: grid;
  grid-template-columns: 1fr minmax(auto, 380px);
  gap: clamp(1.5rem, 5vw, 2.5rem);
}

.card {
  background: var(--white);
  padding: clamp(1.5rem, 4vw, 2.5rem);
  border-radius: clamp(20px, 4vw, 32px);
  border: 1px solid var(--border);
  margin-bottom: clamp(1rem, 3vw, 1.5rem);
  box-shadow: 0 4px 20px rgba(0,0,0,0.05);
}

.profile-hero { 
  display: flex; 
  gap: clamp(1rem, 4vw, 1.5rem); 
  align-items: flex-start; 
  margin-bottom: clamp(1rem, 3vw, 2rem); 
}
.profile-img { 
  width: clamp(100px, 22vw, 140px); 
  height: clamp(100px, 22vw, 140px); 
  border-radius: 50%; 
  object-fit: cover; 
  border: 4px solid var(--primary-light); 
  flex-shrink: 0;
}
.verify-tag { 
  background: var(--primary-light); 
  color: var(--primary); 
  padding: clamp(4px, 1vw, 6px) clamp(10px, 2vw, 14px); 
  border-radius: 50px; 
  font-size: clamp(0.65rem, 2vw, 0.75rem); 
  font-weight: 800; 
  letter-spacing: 0.5px; 
  display: inline-block; 
  margin-bottom: 0.75rem; 
}

.stats-bar { 
  display: grid; 
  grid-template-columns: repeat(3, 1fr); 
  background: #F8FAFC; 
  padding: clamp(1rem, 3vw, 1.5rem); 
  border-radius: clamp(12px, 3vw, 20px); 
  text-align: center;
  gap: 0.5rem;
}
.stat-box { padding: 0.5rem 0; }
.stat-box h4 { 
  font-size: clamp(1rem, 4vw, 1.3rem); 
  font-weight: 800; 
  color: var(--dark); 
}
.stat-box p { 
  font-size: clamp(0.65rem, 2vw, 0.8rem); 
  color: var(--gray); 
  font-weight: 600; 
  text-transform: uppercase; 
  margin: 0;
}

.section-h { 
  font-size: clamp(1.1rem, 3vw, 1.4rem); 
  font-weight: 800; 
  margin: clamp(1.5rem, 4vw, 2.5rem) 0 clamp(0.75rem, 2vw, 1rem); 
}
.about-text {
  color: var(--gray); 
  font-size: clamp(0.9rem, 2.5vw, 1rem); 
  line-height: 1.7;
}
.skills-list { 
  display: flex; 
  flex-wrap: wrap; 
  gap: clamp(6px, 1.5vw, 10px); 
}
.skill-item { 
  background: #F1F5F9; 
  padding: clamp(6px, 1.5vw, 8px) clamp(12px, 3vw, 20px); 
  border-radius: 50px; 
  font-size: clamp(0.75rem, 2vw, 0.9rem); 
  font-weight: 600; 
  color: var(--dark); 
}

.booking-sidebar {
  background: var(--white);
  padding: clamp(1.5rem, 4vw, 2.2rem);
  border-radius: clamp(20px, 4vw, 32px);
  border: 1px solid var(--border);
  position: sticky;
  top: clamp(5rem, 10vh, 6rem);
  height: fit-content;
  box-shadow: 0 clamp(15px, 4vw, 25px) clamp(40px, 8vw, 50px) -12px rgba(0, 0, 0, 0.06);
}

.price-tag { 
  font-size: clamp(1.8rem, 6vw, 2.4rem); 
  font-weight: 800; 
  margin-bottom: clamp(1rem, 3vw, 1.5rem); 
}
.price-tag span { 
  font-size: clamp(0.8rem, 2.5vw, 1rem); 
  color: var(--gray); 
  font-weight: 500; 
}

.availability-badge {
  background: #F0FDF4; 
  color: #15803D; 
  padding: clamp(8px, 2vw, 12px); 
  border-radius: clamp(8px, 2vw, 12px); 
  font-size: clamp(0.7rem, 2vw, 0.85rem); 
  font-weight: 800; 
  text-align: center; 
  margin-bottom: clamp(1.5rem, 4vw, 2rem);
}

.form-label { 
  display: block; 
  font-size: clamp(0.7rem, 2vw, 0.85rem); 
  font-weight: 800; 
  color: var(--gray); 
  margin-bottom: clamp(6px, 1.5vw, 10px); 
  text-transform: uppercase; 
  letter-spacing: 0.5px;
}
.input-field { 
  width: 100%; 
  padding: clamp(12px, 3vw, 16px); 
  border-radius: clamp(10px, 2.5vw, 14px); 
  border: 2px solid var(--border); 
  margin-bottom: clamp(1rem, 3vw, 1.5rem); 
  outline: none; 
  transition: all 0.3s; 
  font-size: clamp(0.9rem, 2.5vw, 1rem); 
  font-weight: 500;
}
.input-field:focus { 
  border-color: var(--primary); 
  background: var(--primary-light); 
  box-shadow: 0 0 0 clamp(2px, 0.5vw, 4px) rgba(124, 58, 237, 0.2);
  transform: translateY(-1px);
}

.btn-book-final { 
  background: linear-gradient(135deg, var(--primary), #A78BFA); 
  color: var(--white); 
  width: 100%; 
  padding: clamp(14px, 4vw, 20px); 
  border-radius: clamp(14px, 3vw, 20px); 
  border: none; 
  font-weight: 800; 
  font-size: clamp(1rem, 3vw, 1.15rem); 
  cursor: pointer; 
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
  margin-top: clamp(8px, 2vw, 12px); 
  text-transform: uppercase;
  letter-spacing: 0.5px;
  box-shadow: 0 clamp(10px, 3vw, 15px) clamp(25px, 6vw, 35px) rgba(124, 58, 237, 0.3);
}
.btn-book-final:hover { 
  transform: translateY(-3px); 
  box-shadow: 0 clamp(20px, 5vw, 30px) clamp(40px, 8vw, 60px) rgba(124, 58, 237, 0.4);
}
.btn-book-final:active {
  transform: translateY(-1px);
}

.note-text {
  text-align: center; 
  font-size: clamp(0.65rem, 2vw, 0.8rem); 
  color: var(--gray); 
  margin-top: clamp(10px, 3vw, 18px);
  line-height: 1.4;
}

.review-card { 
  padding: clamp(1rem, 3vw, 1.5rem) 0; 
  border-top: 1px solid #F1F5F9; 
}
.review-top { 
  display: flex; 
  justify-content: space-between; 
  align-items: center;
  margin-bottom: clamp(6px, 1.5vw, 12px); 
}
.star-rating { 
  color: #F59E0B; 
  font-weight: 700; 
}
.review-text {
  color: var(--gray); 
  font-size: clamp(0.85rem, 2.5vw, 1rem); 
  line-height: 1.6;
}

@media (max-width: 992px) {
  .main-content { 
    grid-template-columns: 1fr; 
    gap: clamp(1rem, 4vw, 2rem);
  }
  .booking-sidebar { 
    position: static; 
    margin-top: clamp(1rem, 3vw, 2rem);
  }
}

@media (max-width: 480px) {
  .profile-hero {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }
  .stats-bar {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>

<div class="main-content">
  <main>
    <section class="card">
      <div class="profile-hero">
        <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=400" class="profile-img" alt="Riya Sharma">
        <div>
          <span class="verify-tag">✓ VERIFIED EXPERT</span>
          <h1 style="font-size: clamp(2rem, 6vw, 2.8rem); font-weight: 900; letter-spacing: -1px; margin: 0;">Riya Sharma</h1>
          <p style="color: var(--gray); font-size: clamp(0.95rem, 3vw, 1.2rem); font-weight: 600; margin: 0.25rem 0 1rem;">Premium Home Cook • 0.8 km away</p>
        </div>
      </div>

      <div class="stats-bar">
        <div class="stat-box">
          <h4>4.9</h4>
          <p>Rating</p>
        </div>
        <div class="stat-box" style="border-left: 1px solid #E2E8F0; border-right: 1px solid #E2E8F0;">
          <h4>124</h4>
          <p>Reviews</p>
        </div>
        <div class="stat-box">
          <h4>52</h4>
          <p>Jobs Done</p>
        </div>
      </div>

      <h3 class="section-h">About the Expert</h3>
      <p class="about-text">
        I am a professional home cook with over 6 years of experience serving families in Mohali and Chandigarh. 
        I specialize in healthy, hygienic, and authentic North Indian meals. Whether you need a daily meal prep 
        service or a chef for a small home gathering, I ensure the highest standards of taste and cleanliness.
      </p>

      <h3 class="section-h">Expertise & Skills</h3>
      <div class="skills-list">
        <div class="skill-item">Punjabi Cuisine</div>
        <div class="skill-item">Keto/Diet Meals</div>
        <div class="skill-item">Party Catering</div>
        <div class="skill-item">Baking</div>
        <div class="skill-item">Grocery Shopping</div>
      </div>
    </section>

    <section class="card">
      <h3 class="section-h" style="margin-top: 0;">Verified Reviews</h3>
      
      <div class="review-card">
        <div class="review-top">
          <span style="font-weight: 800; font-size: clamp(0.9rem, 2.5vw, 1rem);">Rahul Varma</span>
          <span class="star-rating">★★★★★ 5.0</span>
        </div>
        <p class="review-text">"Riya is fantastic! Her cooking reminds me of home. Very professional and keeps the kitchen spotless."</p>
      </div>

      <div class="review-card">
        <div class="review-top">
          <span style="font-weight: 800; font-size: clamp(0.9rem, 2.5vw, 1rem);">Anjali Preet</span>
          <span class="star-rating">★★★★★ 5.0</span>
        </div>
        <p class="review-text">"Hired her for a small birthday lunch. All guests loved the food. Highly recommended for party catering!"</p>
      </div>
    </section>
  </main>

  <aside>
    <div class="booking-sidebar">
      <div class="price-tag">Rs. 1,800 <span>/ day</span></div>
      
      <div class="availability-badge">
        ⚡ AVAILABLE FOR BOOKING TODAY
      </div>

      <label class="form-label">Service Type</label>
      <select class="input-field">
        <option>Daily Meal Prep (Lunch/Dinner)</option>
        <option>One-time Party Catering</option>
        <option>Weekly Subscription</option>
      </select>

      <label class="form-label">Booking Date</label>
      <input type="date" class="input-field">

      <label class="form-label">Your Phone Number</label>
      <input type="tel" class="input-field" placeholder="+91 00000 00000">

      <div style="margin-top: 1rem; padding: clamp(1rem, 3vw, 1.5rem); background: #F8FAFC; border-radius: clamp(12px, 3vw, 16px);">
        <div style="display: flex; justify-content: space-between; font-size: clamp(0.85rem, 2.5vw, 1rem); margin-bottom: 0.5rem;">
          <span>Service Fee</span>
          <span>Rs. 1,800</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: clamp(1rem, 3vw, 1.2rem); color: var(--primary);">
          <span>Total Pay</span>
          <span>Rs. 1,800</span>
        </div>
      </div>

      <button class="btn-book-final" onclick="handleBooking()">Request Booking</button>
      <p class="note-text">You won't be charged yet. The expert will call you to confirm details.</p>
    </div>
  </aside>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Set default date to tomorrow
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  document.querySelector('.input-field[type="date"]').value = tomorrow.toISOString().split('T')[0];
});

function handleBooking() {
  const btn = document.querySelector('.btn-book-final');
  const originalText = btn.innerText;
  btn.innerText = "Sending Request...";
  btn.style.opacity = "0.7";
  
  setTimeout(() => {
    alert("Success! Riya Sharma has received your request and will call you within 15 minutes to confirm.");
    btn.innerText = originalText;
    btn.style.opacity = "1";
  }, 2000);
}
</script>
@endsection

