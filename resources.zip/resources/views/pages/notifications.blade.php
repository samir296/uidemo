@extends('layouts.app')

@section('title', 'HomeEase | Notifications')

@section('content')
<style>
body {
  background:
    radial-gradient(circle at top left, rgba(124, 58, 237, 0.12), transparent 25%),
    linear-gradient(180deg, #FCFBFF 0%, #F8FAFC 100%);
}

.page-shell {
  max-width: 760px;
  margin: 0 auto;
  padding: 1rem;
}

.app-card {
  background: rgba(255,255,255,0.95);
  border: 1px solid rgba(226,232,240,0.96);
  border-radius: 28px;
  padding: clamp(1rem, 4vw, 1.4rem);
  box-shadow: 0 22px 55px rgba(15,23,42,0.06);
}

.head h1 {
  margin: 0 0 0.4rem;
  color: #0F172A;
}

.head p,
.note p {
  color: #64748B;
  line-height: 1.6;
}

.feed {
  display: grid;
  gap: 0.9rem;
  margin-top: 1rem;
}

.item {
  border: 1px solid #E2E8F0;
  border-radius: 20px;
  padding: 1rem;
  background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
}

.item strong {
  display: block;
  margin-bottom: 0.25rem;
  color: #0F172A;
}

.meta {
  display: inline-flex;
  margin-top: 0.7rem;
  padding: 0.4rem 0.7rem;
  border-radius: 999px;
  background: #F5F3FF;
  color: #7C3AED;
  font-size: 0.76rem;
  font-weight: 800;
}

@media (max-width: 640px) {
  .page-shell {
    padding: 0.85rem;
  }

  .app-card {
    border-radius: 22px;
    padding: 1rem;
  }
}
</style>

<div class="page-shell">
  <div class="app-card">
    <div class="head">
      <h1>Notifications</h1>
      <p>Updates are shown in a simple mobile feed so people can check status quickly without digging through menus.</p>
    </div>

    <div class="feed">
      <div class="item">
        <strong>Your cleaner request is confirmed</strong>
        <p>Arrival window updated for tomorrow morning. Review the booking details if you need to reschedule.</p>
        <span class="meta">2 min ago</span>
      </div>
      <div class="item">
        <strong>Payment receipt is ready</strong>
        <p>Your last booking was charged successfully and the receipt is available in your account history.</p>
        <span class="meta">Today</span>
      </div>
      <div class="item">
        <strong>Profile reminder</strong>
        <p>Keep address, contact number, and notification settings updated for smoother service support.</p>
        <span class="meta">Tips</span>
      </div>
    </div>
  </div>
</div>
@endsection
