<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>@yield('title', 'HomeEase')</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
    <link rel="alternate icon" type="image/png" href="{{ asset('logo.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('icons/apple-touch-icon.png') }}">
    <link rel="preload" href="{{ asset('favicon.svg') }}" as="image" type="image/svg+xml">
    <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
    <meta name="theme-color" content="#7C3AED">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="HomeEase">

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        window.HomeEaseFirebaseConfig = {
            apiKey: 'AIzaSyAhYidkUMumBt89hXLGSYyWyjN-Lf1qOx4',
            authDomain: 'testingappcodie.firebaseapp.com',
            projectId: 'testingappcodie',
            storageBucket: 'testingappcodie.firebasestorage.app',
            messagingSenderId: '957303316946',
            appId: '1:957303316946:web:d1a2f11a915a22a6f8a80b',
            measurementId: 'G-1B1C35DQC2',
        };
        window.HomeEaseFirebaseVapidKey = 'BOZzWIvA-yRGKY6c3vZzol3h4jVVQOQERLt-PyniM52E2fqoS4gED6zgAW5l-VEpcGE2aXBevciNfhcdg4qKvG4';
    </script>
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif

    <style>
        /* Layout base styles */
        html { height: 100%; }
        body { min-height: 100vh; margin: 0; font-family: 'Plus Jakarta Sans', sans-serif; overflow-x: hidden; }
    </style>
</head>
<body>

@include('layouts.loader')

    @include('layouts.header')

    <main class="page-content">
        @yield('content')
    </main>

</body>

</html>

